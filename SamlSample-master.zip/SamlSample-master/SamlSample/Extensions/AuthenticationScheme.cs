﻿namespace SamlSample.Extensions
{
    public class AuthenticationScheme
    {
        public const string Saml = "Saml";
    }
}
