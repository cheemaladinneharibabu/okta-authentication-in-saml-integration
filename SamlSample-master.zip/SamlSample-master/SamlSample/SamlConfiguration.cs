﻿namespace SamlSample
{
    public class SamlConfiguration
    {
        public string EntityId { get; set; }

        public string IdentityProviderIssuer { get; set; }

        public string MetadataUrl { get; set; }
    }
}
