using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SamlSample.Pages
{
    public class PublicModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
